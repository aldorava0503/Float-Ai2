# FloatAI — AI assistant floating overlay (Android, Kotlin + Compose)

Proyek native Android: floating bubble + panel chat + **Analisis Layar** via MediaProjection resmi.
Tidak ada stealth, bypass permission, atau penyamaran capture. Indikator capture selalu terlihat
(notifikasi "● Screen capture AKTIF", titik merah pada bubble, dan ikon sistem Android).

## 1. Struktur
```
FloatAI/
├── settings.gradle.kts · build.gradle.kts · gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml
        ├── res/ (values/strings, themes; drawable/ic_launcher, ic_notification)
        └── java/com/floatai/app/
            ├── FloatAIApp.kt            (Application, wiring dependency)
            ├── MainActivity.kt          (izin overlay, start/stop bubble)
            ├── ai/        AIClient.kt (interface+error), OpenAiCompatibleClient.kt
            ├── capture/   ScreenCaptureManager.kt (MediaProjection), ScreenshotProcessor.kt
            ├── data/      SettingsStore.kt (key terenkripsi), ChatRepository.kt, ChatMessage.kt
            ├── overlay/   OverlayManager.kt, DraggableBubbleLayout.kt, OverlayLifecycleOwner.kt, OverlayController.kt
            ├── permission/ PermissionHandler.kt, CaptureRequestActivity.kt
            ├── service/   FloatingService.kt, CaptureService.kt, Notifications.kt
            ├── ui/        ChatViewModel.kt, FloatingPanel.kt, BubbleContent.kt, MainScreen.kt, Theme.kt
            └── util/      DisplayUtil.kt
```

## 2. Menjalankan di Android Studio
1. Android Studio Koala (2024.1) atau lebih baru, JDK 17 (bawaan Studio).
2. **File → Open** → pilih folder `FloatAI`. Tunggu Gradle sync (butuh internet; Studio akan mengunduh
   Gradle 8.7 sesuai `gradle-wrapper.properties`). Jika diminta, install Android SDK 34.
3. Colokkan HP (USB debugging) atau pakai emulator API 26+ → **Run ▶**.

## 3. Build APK debug
- Menu: **Build → Build Bundle(s) / APK(s) → Build APK(s)**, atau terminal
  (setelah Studio membuat `gradlew`): `./gradlew assembleDebug`
- Hasil: `app/build/outputs/apk/debug/app-debug.apk`

## 4. Menghubungkan API AI
Buka aplikasi → bagian **Konfigurasi AI**:

| Field | Contoh |
|---|---|
| `AI_BASE_URL` | `https://api.openai.com/v1` (atau OpenRouter `https://openrouter.ai/api/v1`, dll) |
| `AI_MODEL` | model **yang mendukung gambar**, mis. `gpt-4o-mini` |
| `AI_API_KEY` | key Anda |

- Endpoint yang dipakai: `POST {AI_BASE_URL}/chat/completions` (format OpenAI-compatible).
  Screenshot dikirim sebagai `image_url` berisi data URL JPEG base64.
- **API key tidak ada di APK.** Dimasukkan saat runtime dan disimpan dengan
  `EncryptedSharedPreferences` (Android Keystore). `AI_BASE_URL`/`AI_MODEL` default ada di
  `app/build.gradle.kts` (`buildConfigField`) — jangan taruh key di sana.
- Catatan keamanan: key apa pun yang berada di perangkat pengguna tetap bisa diekstrak oleh pemilik
  perangkat. Untuk distribusi ke orang lain, pakai backend proxy milikmu sendiri yang menyimpan key,
  lalu arahkan `AI_BASE_URL` ke proxy itu.
- Ganti provider non-OpenAI: buat class baru yang mengimplementasikan `AIClient` dan ganti di `FloatAIApp.kt`.

## 5. Izin yang dipakai
| Izin | Alasan |
|---|---|
| `SYSTEM_ALERT_WINDOW` | menampilkan bubble/panel di atas aplikasi lain (diberikan manual di Settings) |
| MediaProjection (dialog sistem) | screenshot layar; diminta saat pertama kali menekan Analisis/Refresh |
| `FOREGROUND_SERVICE` (+ `SPECIAL_USE`, `MEDIA_PROJECTION`) | service overlay & capture wajib punya notifikasi |
| `POST_NOTIFICATIONS` | agar notifikasi/indikator terlihat (Android 13+) |
| `INTERNET` | memanggil API AI |

## 6. Cara menguji
**Floating bubble**
1. Buka FloatAI → **Beri izin overlay** → aktifkan untuk FloatAI → kembali.
2. Tekan **Aktifkan bubble**. Buka aplikasi lain (mis. browser).
3. Bubble "AI" tampil: drag → menempel ke sisi; tap → panel chat; tombol **—** = minimize ke bubble;
   **✕** = matikan FloatAI. Atur ukuran/transparansi/sisi di halaman utama.

**Screen capture**
1. Isi konfigurasi API (di atas), buka halaman berisi soal/teks di aplikasi lain.
2. Tap bubble → **📷 Analisis**. Dialog Android muncul → setujui (di Android 14+ pilih "Seluruh layar").
3. Panel/bubble disembunyikan ±0,35 detik hanya agar AI tidak membaca panelnya sendiri, lalu
   screenshot diambil, (dikonfirmasi bila opsi privasi aktif), dikirim, dan jawaban tampil di chat.
4. Pindah halaman → **🔄 Refresh** → tanya lagi. Bot hanya memakai screenshot terakhir yang Anda ambil.
5. **⏹ Stop Capture** (atau tombol "Berhenti" di notifikasi) menghentikan capture; indikator hilang.

## 7. Perilaku & batasan yang perlu diketahui
- Panel chat memakai window yang bisa fokus (supaya keyboard muncul); saat panel terbuka, input ke aplikasi
  di bawahnya sementara tidak aktif — minimize ke bubble untuk memakai aplikasi lain.
- Konten yang menyetel `FLAG_SECURE` (banking, beberapa app video/ujian) tampil hitam di screenshot — itu mekanisme
  keamanan Android dan **tidak** dicoba dilewati.
- Rotasi layar saat capture aktif: hentikan lalu mulai capture lagi agar ukuran frame sesuai.
- Kode ini ditulis tanpa dikompilasi di lingkungan pembuatnya; jika Gradle sync/compile menampilkan error versi
  dependency, sesuaikan versi di `app/build.gradle.kts` sesuai saran Android Studio.
- Gunakan sesuai aturan sekolah/ujian/platform yang berlaku; untuk ujian yang melarang bantuan AI, jangan dipakai.
