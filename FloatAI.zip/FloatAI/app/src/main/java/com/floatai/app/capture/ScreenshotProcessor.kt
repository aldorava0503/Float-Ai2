package com.floatai.app.capture

import android.graphics.Bitmap
import android.util.Base64
import com.floatai.app.ai.AiException
import java.io.ByteArrayOutputStream
import kotlin.math.max
import kotlin.math.min

/** Screenshot hanya hidup di memori (base64 JPEG). Tidak pernah ditulis ke disk. */
data class Screenshot(
    val base64Jpeg: String,
    val width: Int,
    val height: Int,
    val takenAt: Long
)

object ScreenshotProcessor {
    private const val MAX_DIMENSION = 1280
    private const val MAX_BYTES = 3_500_000

    fun process(src: Bitmap): Screenshot {
        var scale = min(1f, MAX_DIMENSION.toFloat() / max(src.width, src.height))
        var quality = 80
        for (attempt in 0 until 4) {
            val w = (src.width * scale).toInt().coerceAtLeast(1)
            val h = (src.height * scale).toInt().coerceAtLeast(1)
            val bmp = if (scale < 1f) Bitmap.createScaledBitmap(src, w, h, true) else src
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, quality, out)
            if (bmp !== src) bmp.recycle()
            val bytes = out.toByteArray()
            if (bytes.size <= MAX_BYTES) {
                return Screenshot(
                    base64Jpeg = Base64.encodeToString(bytes, Base64.NO_WRAP),
                    width = w,
                    height = h,
                    takenAt = System.currentTimeMillis()
                )
            }
            scale *= 0.75f
            quality = (quality - 10).coerceAtLeast(50)
        }
        throw AiException.ImageTooLarge()
    }
}
