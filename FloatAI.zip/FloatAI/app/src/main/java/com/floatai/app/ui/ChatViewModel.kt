package com.floatai.app.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.floatai.app.ai.AIClient
import com.floatai.app.ai.AiException
import com.floatai.app.capture.ScreenCaptureManager
import com.floatai.app.capture.Screenshot
import com.floatai.app.capture.ScreenshotProcessor
import com.floatai.app.data.ChatMessage
import com.floatai.app.data.ChatRepository
import com.floatai.app.data.Role
import com.floatai.app.data.SettingsStore
import com.floatai.app.overlay.OverlayController
import com.floatai.app.util.TimeUtil
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val COMMON_PROMPT = """Kamu adalah FloatAI, asisten AI yang tampil sebagai floating overlay di Android.
Jawab dalam bahasa yang dipakai pengguna (default Bahasa Indonesia). Jawaban harus ringkas, rapi, dan mudah dibaca di layar kecil.
Aturan screenshot:
- Jika ada screenshot, itu adalah SATU-SATUNYA sumber informasi tentang isi layar. Jangan mengarang hal yang tidak terlihat. Jika teks buram atau terpotong, katakan terus terang.
- Screenshot hanya mewakili layar pada waktu yang tertera. Jangan berasumsi layar masih sama setelahnya.
- Jika screenshot tampak memuat password, OTP, kartu pembayaran, atau data pribadi sensitif, awali jawaban dengan satu baris "⚠️ Layar tampak memuat data sensitif (jenisnya)." lalu lanjutkan tanpa mengulang data sensitif tersebut."""

enum class ChatMode(
    val label: String,
    val usesScreen: Boolean,
    private val instructions: String,
    val defaultPrompt: String
) {
    CHAT(
        "Chat", false,
        "Mode Chat: jawab pertanyaan umum pengguna dengan jelas dan membantu.",
        ""
    ),
    SCREEN(
        "Analisis Layar", true,
        "Mode Analisis Layar: baca dan jelaskan isi screenshot terbaru (teks, tabel, diagram sederhana, gambar relevan, halaman web/aplikasi), lalu jelaskan apa yang perlu dilakukan pengguna.",
        "Analisis layar saya: jelaskan isinya dan apa yang perlu saya lakukan."
    ),
    HOMEWORK(
        "Bantuan Soal", true,
        """Mode Bantuan Soal: fokus pada soal yang terlihat. Tulis ulang inti soal secara singkat, tentukan konsep/rumus, jelaskan langkah, hitung, dan beri jawaban akhir. Sesuaikan penjelasan agar mudah dipahami siswa.
Format: Matematika = rumus, substitusi angka, perhitungan, jawaban akhir. Fisika = diketahui, ditanya, rumus, substitusi, hasil. Kimia = identifikasi konsep, persamaan/rumus, perhitungan, hasil. Pilihan ganda = analisis tiap opsi, pilih jawaban, alasan singkat.""",
        "Identifikasi soal yang terlihat di layar, lalu bantu kerjakan langkah demi langkah."
    ),
    EXPLAIN(
        "Jelaskan", true,
        "Mode Jelaskan: terangkan materi atau bagian layar dengan bahasa sederhana, boleh pakai analogi singkat.",
        "Jelaskan bagian layar ini dengan bahasa sederhana."
    ),
    NEXT(
        "Langkah Berikutnya", true,
        "Mode Langkah Berikutnya: berdasarkan kondisi layar yang terlihat, jelaskan tindakan berikutnya yang sebaiknya dilakukan pengguna secara berurutan.",
        "Berdasarkan layar ini, apa langkah berikutnya yang harus saya lakukan?"
    );

    fun systemPrompt(): String = COMMON_PROMPT + "\n\n" + instructions
}

data class PendingSend(val prompt: String, val screenshot: Screenshot)

data class ChatUiState(
    val loading: Boolean = false,
    val mode: ChatMode = ChatMode.CHAT,
    val screenshotTime: Long? = null,
    val pending: PendingSend? = null,
    val waitingPermission: Boolean = false
)

private enum class ScreenAction { ANALYZE, REFRESH }

class ChatViewModel(
    private val repo: ChatRepository,
    private val settings: SettingsStore,
    private val ai: AIClient
) : ViewModel() {

    private val _state = MutableStateFlow(ChatUiState())
    val state: StateFlow<ChatUiState> = _state.asStateFlow()
    val messages: StateFlow<List<ChatMessage>> = repo.messages

    /** Teks input; disimpan di sini agar tidak hilang saat panel diminimize. */
    var draft by mutableStateOf("")

    var overlayController: OverlayController? = null
    var permissionRequester: (() -> Unit)? = null

    private var latestScreenshot: Screenshot? = null
    private var confirmedShotTime: Long? = null
    private var pendingAction: ScreenAction? = null
    private var job: Job? = null

    init {
        viewModelScope.launch {
            ScreenCaptureManager.active.collect { active ->
                if (!active) {
                    latestScreenshot = null
                    confirmedShotTime = null
                    _state.update { it.copy(screenshotTime = null, pending = null) }
                } else {
                    val action = pendingAction
                    if (action != null) {
                        pendingAction = null
                        runAction(action)
                    }
                }
            }
        }
        viewModelScope.launch {
            ScreenCaptureManager.denied.collect {
                pendingAction = null
                _state.update { it.copy(waitingPermission = false) }
                info("Izin screen capture ditolak. Fitur layar tidak aktif.")
            }
        }
    }

    fun setMode(mode: ChatMode) = _state.update { it.copy(mode = mode) }

    fun analyzeScreen() = requestScreenAction(ScreenAction.ANALYZE)
    fun refreshScreen() = requestScreenAction(ScreenAction.REFRESH)

    fun stopCapture() {
        ScreenCaptureManager.stop()
        info("Screen capture dihentikan.")
    }

    fun clearChat() {
        job?.cancel()
        repo.clear()
        _state.update { it.copy(loading = false, pending = null) }
    }

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || _state.value.loading) return
        val mode = _state.value.mode
        if (mode.usesScreen) {
            val shot = latestScreenshot
            if (shot == null) {
                info("Belum ada screenshot. Tekan 📷 Analisis atau 🔄 Refresh dulu.")
                return
            }
            sendWithScreenshot(t, shot)
        } else {
            dispatch(t, null)
        }
    }

    fun confirmSend() {
        val p = _state.value.pending ?: return
        confirmedShotTime = p.screenshot.takenAt
        _state.update { it.copy(pending = null) }
        dispatch(p.prompt, p.screenshot)
    }

    fun cancelSend() {
        _state.update { it.copy(pending = null) }
        info("Pengiriman dibatalkan. Screenshot tidak dikirim.")
    }

    fun dispose() {
        job?.cancel()
        viewModelScope.cancel()
    }

    // ---------------- internal ----------------

    private fun requestScreenAction(action: ScreenAction) {
        val s = _state.value
        if (s.loading || s.waitingPermission) return
        if (!ScreenCaptureManager.active.value) {
            pendingAction = action
            _state.update { it.copy(waitingPermission = true) }
            info("Menunggu izin Screen Capture dari Android…")
            permissionRequester?.invoke()
            return
        }
        runAction(action)
    }

    private fun runAction(action: ScreenAction) {
        _state.update { it.copy(waitingPermission = false, loading = true) }
        viewModelScope.launch {
            try {
                val shot = captureShot()
                latestScreenshot = shot
                _state.update { it.copy(screenshotTime = shot.takenAt, loading = false) }
                when (action) {
                    ScreenAction.REFRESH ->
                        info("Layar diperbarui pukul ${TimeUtil.hm(shot.takenAt)}. Tanyakan sesuatu atau tekan 📷 Analisis.")
                    ScreenAction.ANALYZE -> {
                        var mode = _state.value.mode
                        if (!mode.usesScreen) {
                            mode = ChatMode.SCREEN
                            setMode(mode)
                        }
                        sendWithScreenshot(mode.defaultPrompt, shot)
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: AiException) {
                _state.update { it.copy(loading = false) }
                error(e.userMessage)
            } catch (e: Exception) {
                _state.update { it.copy(loading = false) }
                error(e.message ?: "Gagal mengambil screenshot.")
            }
        }
    }

    private suspend fun captureShot(): Screenshot {
        val ctrl = overlayController
        ctrl?.hideForCapture()
        try {
            val bmp = ScreenCaptureManager.capture()
            return withContext(Dispatchers.Default) { ScreenshotProcessor.process(bmp) }
        } finally {
            ctrl?.restoreAfterCapture()
        }
    }

    private fun sendWithScreenshot(prompt: String, shot: Screenshot) {
        val needConfirm = settings.current.confirmBeforeSend && confirmedShotTime != shot.takenAt
        if (needConfirm) _state.update { it.copy(pending = PendingSend(prompt, shot)) }
        else dispatch(prompt, shot)
    }

    private fun dispatch(prompt: String, shot: Screenshot?) {
        val mode = _state.value.mode
        repo.add(ChatMessage(role = Role.USER, text = prompt, hasScreenshot = shot != null))
        _state.update { it.copy(loading = true) }
        job = viewModelScope.launch {
            try {
                val history = repo.conversationForAi().toMutableList()
                if (shot != null && history.isNotEmpty()) {
                    val last = history.last()
                    history[history.lastIndex] = last.copy(
                        text = "[Screenshot diambil pukul ${TimeUtil.hm(shot.takenAt)}]\n${last.text}",
                        imageBase64Jpeg = shot.base64Jpeg
                    )
                }
                val answer = ai.complete(mode.systemPrompt(), history)
                repo.add(ChatMessage(role = Role.ASSISTANT, text = answer))
            } catch (e: CancellationException) {
                throw e
            } catch (e: AiException) {
                error(e.userMessage)
            } catch (e: Exception) {
                error("Terjadi kesalahan: ${e.message}")
            } finally {
                _state.update { it.copy(loading = false) }
            }
        }
    }

    private fun info(text: String) = repo.add(ChatMessage(role = Role.INFO, text = text))
    private fun error(text: String) =
        repo.add(ChatMessage(role = Role.ASSISTANT, text = text, isError = true))
}
