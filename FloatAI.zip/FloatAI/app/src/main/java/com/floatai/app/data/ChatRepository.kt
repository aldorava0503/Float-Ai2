package com.floatai.app.data

import android.content.Context
import com.floatai.app.ai.AiMessage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONArray
import org.json.JSONObject

/** Riwayat chat (hanya teks; screenshot TIDAK pernah disimpan). */
class ChatRepository(context: Context, private val settings: SettingsStore) {
    private val prefs =
        context.applicationContext.getSharedPreferences("floatai_history", Context.MODE_PRIVATE)

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    init {
        if (settings.current.saveHistory) _messages.value = readPersisted()
    }

    fun add(message: ChatMessage) {
        _messages.update { it + message }
        persistIfEnabled()
    }

    fun clear() {
        _messages.value = emptyList()
        prefs.edit().clear().apply()
    }

    fun onSaveHistoryChanged(enabled: Boolean) {
        if (enabled) persistIfEnabled() else prefs.edit().clear().apply()
    }

    /** Riwayat untuk dikirim ke AI sebagai konteks (pertanyaan lanjutan). */
    fun conversationForAi(maxItems: Int = 20): List<AiMessage> =
        _messages.value
            .filter { it.role != Role.INFO && !it.isError }
            .takeLast(maxItems)
            .map { AiMessage(if (it.role == Role.USER) "user" else "assistant", it.text) }

    private fun persistIfEnabled() {
        if (!settings.current.saveHistory) return
        val arr = JSONArray()
        _messages.value.takeLast(200).forEach {
            arr.put(
                JSONObject()
                    .put("role", it.role.name)
                    .put("text", it.text)
                    .put("time", it.time)
                    .put("error", it.isError)
            )
        }
        prefs.edit().putString("messages", arr.toString()).apply()
    }

    private fun readPersisted(): List<ChatMessage> = runCatching {
        val arr = JSONArray(prefs.getString("messages", "[]") ?: "[]")
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            ChatMessage(
                role = Role.valueOf(o.getString("role")),
                text = o.getString("text"),
                time = o.getLong("time"),
                isError = o.optBoolean("error", false)
            )
        }
    }.getOrDefault(emptyList())
}
