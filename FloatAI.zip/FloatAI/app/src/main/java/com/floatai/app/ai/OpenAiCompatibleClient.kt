package com.floatai.app.ai

import com.floatai.app.data.SettingsStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.ConnectException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

/**
 * Klien untuk API berformat OpenAI Chat Completions (OpenAI, OpenRouter, Gemini OpenAI-compat,
 * Ollama/LM Studio, dll). Gambar dikirim sebagai data URL base64 pada content "image_url".
 */
class OpenAiCompatibleClient(private val settings: SettingsStore) : AIClient {

    override suspend fun complete(systemPrompt: String, messages: List<AiMessage>): String =
        withContext(Dispatchers.IO) {
            val s = settings.current
            val key = settings.apiKey()
            if (key.isBlank() || s.baseUrl.isBlank() || s.model.isBlank()) throw AiException.NotConfigured()

            val body = buildBody(s.model, systemPrompt, messages)
            var conn: HttpURLConnection? = null
            try {
                val url = URL(s.baseUrl.trim().trimEnd('/') + "/chat/completions")
                conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15_000
                    readTimeout = 90_000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Authorization", "Bearer $key")
                }
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()

                when {
                    code in 200..299 -> parse(text)
                    code == 401 || code == 403 -> throw AiException.InvalidKey()
                    code == 429 -> throw AiException.RateLimit()
                    code == 413 -> throw AiException.ImageTooLarge()
                    else -> throw AiException.Api(code, extractError(text))
                }
            } catch (e: AiException) {
                throw e
            } catch (e: SocketTimeoutException) {
                throw AiException.Timeout()
            } catch (e: UnknownHostException) {
                throw AiException.NoInternet()
            } catch (e: ConnectException) {
                throw AiException.NoInternet()
            } catch (e: IOException) {
                throw AiException.NoInternet()
            } catch (e: JSONException) {
                throw AiException.EmptyResponse()
            } finally {
                conn?.disconnect()
            }
        }

    private fun buildBody(model: String, system: String, messages: List<AiMessage>): String {
        val arr = JSONArray()
        arr.put(JSONObject().put("role", "system").put("content", system))
        for (m in messages) {
            val o = JSONObject().put("role", m.role)
            if (m.imageBase64Jpeg != null) {
                val parts = JSONArray()
                parts.put(JSONObject().put("type", "text").put("text", m.text))
                parts.put(
                    JSONObject().put("type", "image_url").put(
                        "image_url",
                        JSONObject().put("url", "data:image/jpeg;base64," + m.imageBase64Jpeg)
                    )
                )
                o.put("content", parts)
            } else {
                o.put("content", m.text)
            }
            arr.put(o)
        }
        return JSONObject().put("model", model).put("messages", arr).toString()
    }

    private fun parse(text: String): String {
        val content = JSONObject(text)
            .optJSONArray("choices")?.optJSONObject(0)
            ?.optJSONObject("message")?.optString("content", "").orEmpty()
        if (content.isBlank()) throw AiException.EmptyResponse()
        return content.trim()
    }

    private fun extractError(text: String): String = try {
        JSONObject(text).optJSONObject("error")?.optString("message").orEmpty()
            .ifBlank { text.take(200) }
    } catch (e: JSONException) {
        text.take(200)
    }
}
