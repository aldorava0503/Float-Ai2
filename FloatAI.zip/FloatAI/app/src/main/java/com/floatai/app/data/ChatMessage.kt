package com.floatai.app.data

enum class Role { USER, ASSISTANT, INFO }

data class ChatMessage(
    val id: Long = System.nanoTime(),
    val role: Role,
    val text: String,
    val time: Long = System.currentTimeMillis(),
    val isError: Boolean = false,
    val hasScreenshot: Boolean = false
)
