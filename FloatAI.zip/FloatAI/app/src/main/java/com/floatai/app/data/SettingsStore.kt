package com.floatai.app.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.floatai.app.BuildConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class BubbleSide { LEFT, RIGHT, NEAREST }

data class AppSettings(
    val baseUrl: String,
    val model: String,
    val hasApiKey: Boolean,
    val bubbleSizeDp: Int,
    val bubbleAlpha: Float,
    val bubbleSide: BubbleSide,
    val bubbleY: Int,
    val saveHistory: Boolean,
    val confirmBeforeSend: Boolean
)

/**
 * Pengaturan biasa disimpan di SharedPreferences.
 * API key disimpan terenkripsi (EncryptedSharedPreferences + Android Keystore).
 */
class SettingsStore(context: Context) {
    private val appContext = context.applicationContext
    private val prefs: SharedPreferences =
        appContext.getSharedPreferences("floatai_settings", Context.MODE_PRIVATE)
    private val securePrefs: SharedPreferences? = runCatching { createSecurePrefs() }.getOrNull()
    private var memoryKey: String = ""

    private val _flow = MutableStateFlow(load())
    val flow: StateFlow<AppSettings> = _flow.asStateFlow()
    val current: AppSettings get() = _flow.value

    private fun createSecurePrefs(): SharedPreferences {
        val masterKey = MasterKey.Builder(appContext)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        return EncryptedSharedPreferences.create(
            appContext,
            "floatai_secure",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun apiKey(): String = securePrefs?.getString("api_key", "") ?: memoryKey

    fun setApiKey(key: String) {
        val trimmed = key.trim()
        if (securePrefs != null) securePrefs.edit().putString("api_key", trimmed).apply()
        else memoryKey = trimmed
        _flow.value = load()
    }

    fun update(block: (AppSettings) -> AppSettings) {
        val n = block(_flow.value)
        prefs.edit()
            .putString("base_url", n.baseUrl.trim())
            .putString("model", n.model.trim())
            .putInt("bubble_size", n.bubbleSizeDp)
            .putFloat("bubble_alpha", n.bubbleAlpha)
            .putString("bubble_side", n.bubbleSide.name)
            .putInt("bubble_y", n.bubbleY)
            .putBoolean("save_history", n.saveHistory)
            .putBoolean("confirm_send", n.confirmBeforeSend)
            .apply()
        _flow.value = load()
    }

    fun clearAll() {
        prefs.edit().clear().apply()
        securePrefs?.edit()?.clear()?.apply()
        memoryKey = ""
        _flow.value = load()
    }

    private fun load(): AppSettings = AppSettings(
        baseUrl = prefs.getString("base_url", BuildConfig.AI_BASE_URL) ?: BuildConfig.AI_BASE_URL,
        model = prefs.getString("model", BuildConfig.AI_MODEL) ?: BuildConfig.AI_MODEL,
        hasApiKey = apiKey().isNotBlank(),
        bubbleSizeDp = prefs.getInt("bubble_size", 56),
        bubbleAlpha = prefs.getFloat("bubble_alpha", 0.9f),
        bubbleSide = runCatching {
            BubbleSide.valueOf(prefs.getString("bubble_side", "NEAREST") ?: "NEAREST")
        }.getOrDefault(BubbleSide.NEAREST),
        bubbleY = prefs.getInt("bubble_y", 400),
        saveHistory = prefs.getBoolean("save_history", false),
        confirmBeforeSend = prefs.getBoolean("confirm_send", true)
    )
}
