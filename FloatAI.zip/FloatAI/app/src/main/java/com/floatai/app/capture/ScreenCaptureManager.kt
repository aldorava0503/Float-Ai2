package com.floatai.app.capture

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import com.floatai.app.util.DisplayUtil
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Pengelola MediaProjection resmi. Capture aktif hanya setelah pengguna menyetujui dialog sistem,
 * dan berhenti saat pengguna menekan "Berhenti" / menghentikan dari sistem.
 * Frame hanya diambil ketika capture() dipanggil oleh aksi pengguna (Analisis / Refresh).
 */
object ScreenCaptureManager {
    private val _active = MutableStateFlow(false)
    val active: StateFlow<Boolean> = _active.asStateFlow()

    private val _denied = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val denied: SharedFlow<Unit> = _denied.asSharedFlow()

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var lastBitmap: Bitmap? = null
    private var width = 0
    private var height = 0

    fun reportDenied() {
        _denied.tryEmit(Unit)
    }

    @Synchronized
    fun start(context: Context, mp: MediaProjection) {
        release()
        val size = DisplayUtil.realSize(context)
        width = size.x
        height = size.y
        val dpi = context.resources.displayMetrics.densityDpi

        projection = mp
        // Wajib didaftarkan sebelum createVirtualDisplay (Android 14+).
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                if (projection === mp) stop()
            }
        }, Handler(Looper.getMainLooper()))

        val r = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        reader = r
        display = mp.createVirtualDisplay(
            "FloatAI-ScreenCapture", width, height, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            r.surface, null, null
        )
        _active.value = true
    }

    @Synchronized
    fun stop() {
        release()
        _active.value = false
    }

    private fun release() {
        display?.release(); display = null
        reader?.close(); reader = null
        val p = projection
        projection = null
        p?.stop()
        lastBitmap?.recycle(); lastBitmap = null
    }

    /**
     * Mengambil frame terbaru. Jika tidak ada frame baru (layar tidak berubah sejak capture terakhir),
     * frame cache terakhir tetap valid karena layar memang sama.
     */
    suspend fun capture(): Bitmap {
        val r = reader ?: throw IllegalStateException("Screen capture belum aktif.")
        var waited = 0
        while (waited < 2000) {
            val image = try { r.acquireLatestImage() } catch (e: IllegalStateException) { null }
            if (image != null) {
                try {
                    val bmp = imageToBitmap(image)
                    lastBitmap?.recycle()
                    lastBitmap = bmp
                    return bmp
                } finally {
                    image.close()
                }
            }
            val cached = lastBitmap
            if (cached != null && waited >= 150) return cached
            delay(50)
            waited += 50
        }
        throw IllegalStateException("Gagal mengambil frame layar. Coba tekan Refresh Layar lagi.")
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val pixelStride = plane.pixelStride
        val rowPadding = plane.rowStride - pixelStride * width
        val padded = Bitmap.createBitmap(
            width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888
        )
        padded.copyPixelsFromBuffer(plane.buffer)
        val cropped = Bitmap.createBitmap(padded, 0, 0, width, height)
        if (cropped !== padded) padded.recycle()
        return cropped
    }
}
