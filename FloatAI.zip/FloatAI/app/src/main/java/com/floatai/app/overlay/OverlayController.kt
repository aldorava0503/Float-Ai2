package com.floatai.app.overlay

/** Dipakai ViewModel agar overlay FloatAI sendiri tidak ikut tertangkap di screenshot. */
interface OverlayController {
    suspend fun hideForCapture()
    fun restoreAfterCapture()
}
