package com.floatai.app.ai

/** role: "user" atau "assistant". imageBase64Jpeg hanya diisi untuk pesan yang membawa screenshot. */
data class AiMessage(
    val role: String,
    val text: String,
    val imageBase64Jpeg: String? = null
)

sealed class AiException(val userMessage: String) : Exception(userMessage) {
    class NotConfigured : AiException("API belum dikonfigurasi. Buka aplikasi FloatAI → isi Base URL, Model, dan API Key.")
    class NoInternet : AiException("Tidak ada koneksi internet atau server tidak dapat dijangkau.")
    class Timeout : AiException("Permintaan melebihi batas waktu. Coba lagi.")
    class InvalidKey : AiException("API key tidak valid atau tidak punya akses (401/403).")
    class RateLimit : AiException("Terlalu banyak permintaan / kuota habis (429). Tunggu sebentar lalu coba lagi.")
    class ImageTooLarge : AiException("Screenshot terlalu besar untuk dikirim. Coba lagi atau gunakan model lain.")
    class EmptyResponse : AiException("AI mengembalikan jawaban kosong. Coba ulangi pertanyaan.")
    class Api(val code: Int, detail: String) : AiException("Error API ($code): $detail")
}

/** Abstraksi provider AI. Ganti implementasi tanpa menyentuh UI/ViewModel. */
interface AIClient {
    @Throws(AiException::class)
    suspend fun complete(systemPrompt: String, messages: List<AiMessage>): String
}
