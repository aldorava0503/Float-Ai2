package com.floatai.app

import android.Manifest
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.floatai.app.capture.ScreenCaptureManager
import com.floatai.app.permission.PermissionHandler
import com.floatai.app.service.FloatingService
import com.floatai.app.ui.FloatAITheme
import com.floatai.app.ui.MainScreen

class MainActivity : ComponentActivity() {
    private var overlayGranted by mutableStateOf(false)

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* opsional */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as FloatAIApp
        setContent {
            FloatAITheme {
                MainScreen(
                    settings = app.settings,
                    overlayGranted = overlayGranted,
                    onRequestOverlay = { startActivity(PermissionHandler.overlaySettingsIntent(this)) },
                    onStartBubble = { startBubble() },
                    onStopBubble = { FloatingService.stop(this) },
                    onClearHistory = {
                        app.chatRepository.clear()
                        Toast.makeText(this, "Riwayat dihapus", Toast.LENGTH_SHORT).show()
                    },
                    onClearAll = {
                        FloatingService.stop(this)
                        ScreenCaptureManager.stop()
                        app.chatRepository.clear()
                        app.settings.clearAll()
                        Toast.makeText(this, "Semua data lokal dihapus", Toast.LENGTH_SHORT).show()
                    },
                    onSaveHistoryChanged = { app.chatRepository.onSaveHistoryChanged(it) }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        overlayGranted = PermissionHandler.canDrawOverlays(this)
    }

    private fun startBubble() {
        if (!PermissionHandler.canDrawOverlays(this)) {
            startActivity(PermissionHandler.overlaySettingsIntent(this))
            return
        }
        if (PermissionHandler.needsNotificationPermission(this)) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        FloatingService.start(this)
    }
}
