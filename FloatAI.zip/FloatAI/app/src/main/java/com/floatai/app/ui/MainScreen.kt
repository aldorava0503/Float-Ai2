package com.floatai.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.floatai.app.capture.ScreenCaptureManager
import com.floatai.app.data.BubbleSide
import com.floatai.app.data.SettingsStore
import com.floatai.app.service.FloatingService

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    settings: SettingsStore,
    overlayGranted: Boolean,
    onRequestOverlay: () -> Unit,
    onStartBubble: () -> Unit,
    onStopBubble: () -> Unit,
    onClearHistory: () -> Unit,
    onClearAll: () -> Unit,
    onSaveHistoryChanged: (Boolean) -> Unit
) {
    val s by settings.flow.collectAsState()
    val running by FloatingService.running.collectAsState()
    val captureActive by ScreenCaptureManager.active.collectAsState()

    var baseUrl by remember(s.baseUrl) { mutableStateOf(s.baseUrl) }
    var model by remember(s.model) { mutableStateOf(s.model) }
    var apiKey by remember(s.hasApiKey) { mutableStateOf("") }
    var saved by remember { mutableStateOf(false) }

    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("FloatAI", fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text(
                "Asisten AI melayang. Membaca layar hanya lewat screenshot yang Anda minta dan setujui.",
                fontSize = 13.sp
            )

            Section("Status & Izin") {
                Text(if (overlayGranted) "✅ Izin overlay: diberikan" else "❌ Izin overlay: belum diberikan")
                if (!overlayGranted) Button(onClick = onRequestOverlay) { Text("Beri izin overlay") }
                Text(if (captureActive) "🔴 Screen capture: AKTIF" else "⚪ Screen capture: tidak aktif")
                if (captureActive) OutlinedButton(onClick = { ScreenCaptureManager.stop() }) {
                    Text("Berhenti Screen Capture")
                }
                if (running) OutlinedButton(onClick = onStopBubble) { Text("Matikan bubble") }
                else Button(onClick = onStartBubble) { Text("Aktifkan bubble") }
            }

            Section("Konfigurasi AI") {
                Text(
                    "Isi AI_BASE_URL, AI_MODEL, dan AI_API_KEY. Key disimpan terenkripsi di perangkat, tidak ada di APK.",
                    fontSize = 12.sp
                )
                OutlinedTextField(
                    value = baseUrl, onValueChange = { baseUrl = it; saved = false },
                    label = { Text("AI_BASE_URL") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
                )
                OutlinedTextField(
                    value = model, onValueChange = { model = it; saved = false },
                    label = { Text("AI_MODEL (harus mendukung gambar/vision)") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = apiKey, onValueChange = { apiKey = it; saved = false },
                    label = { Text("AI_API_KEY") },
                    placeholder = { Text(if (s.hasApiKey) "Tersimpan (kosongkan jika tidak diubah)" else "sk-...") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                Button(onClick = {
                    settings.update { it.copy(baseUrl = baseUrl, model = model) }
                    if (apiKey.isNotBlank()) settings.setApiKey(apiKey)
                    apiKey = ""
                    saved = true
                }) { Text("Simpan") }
                if (saved) Text("✅ Tersimpan", fontSize = 12.sp)
            }

            Section("Bubble") {
                Text("Ukuran: ${s.bubbleSizeDp} dp", fontSize = 13.sp)
                Slider(
                    value = s.bubbleSizeDp.toFloat(),
                    onValueChange = { v -> settings.update { it.copy(bubbleSizeDp = v.toInt()) } },
                    valueRange = 40f..88f
                )
                Text("Transparansi (opacity): ${(s.bubbleAlpha * 100).toInt()}%", fontSize = 13.sp)
                Slider(
                    value = s.bubbleAlpha,
                    onValueChange = { v -> settings.update { it.copy(bubbleAlpha = v) } },
                    valueRange = 0.3f..1f
                )
                Text("Posisi tempel", fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(BubbleSide.LEFT to "Kiri", BubbleSide.RIGHT to "Kanan", BubbleSide.NEAREST to "Otomatis")
                        .forEach { (side, label) ->
                            FilterChip(
                                selected = s.bubbleSide == side,
                                onClick = { settings.update { it.copy(bubbleSide = side) } },
                                label = { Text(label) }
                            )
                        }
                }
            }

            Section("Privasi") {
                Text(
                    "• Screenshot hanya diambil saat Anda menekan Analisis/Refresh.\n" +
                        "• Screenshot hanya di memori, tidak disimpan ke penyimpanan.\n" +
                        "• Screenshot dikirim ke penyedia AI yang Anda atur di atas.",
                    fontSize = 12.sp
                )
                ToggleRow("Simpan riwayat chat (teks saja)", s.saveHistory) { on ->
                    settings.update { it.copy(saveHistory = on) }
                    onSaveHistoryChanged(on)
                }
                ToggleRow("Konfirmasi sebelum kirim screenshot", s.confirmBeforeSend) { on ->
                    settings.update { it.copy(confirmBeforeSend = on) }
                }
                OutlinedButton(onClick = onClearHistory) { Text("Hapus riwayat chat") }
                OutlinedButton(
                    onClick = onClearAll,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) { Text("Hapus semua data lokal (termasuk API key)") }
            }
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            content()
        }
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
