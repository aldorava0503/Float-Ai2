package com.floatai.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.floatai.app.capture.ScreenCaptureManager
import com.floatai.app.data.ChatMessage
import com.floatai.app.data.Role
import com.floatai.app.util.TimeUtil

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FloatingPanel(vm: ChatViewModel, onMinimize: () -> Unit, onClose: () -> Unit) {
    val messages by vm.messages.collectAsState()
    val state by vm.state.collectAsState()
    val captureActive by ScreenCaptureManager.active.collectAsState()
    val listState = rememberLazyListState()
    val focusRequester = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current

    val extra = (if (state.pending != null) 1 else 0) + (if (state.loading) 1 else 0)
    LaunchedEffect(messages.size, state.loading, state.pending) {
        val total = messages.size + extra
        if (total > 0) listState.animateScrollToItem(total - 1)
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        shape = RoundedCornerShape(20.dp),
        tonalElevation = 6.dp,
        shadowElevation = 10.dp
    ) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            // Header
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(Color(0xFF6C5CE7), Color(0xFF00B8D9)))),
                    contentAlignment = Alignment.Center
                ) { Text("AI", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                Spacer(Modifier.size(8.dp))
                Text("FloatAI", fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                IconButton(onClick = { vm.clearChat() }, modifier = Modifier.size(34.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "Hapus percakapan")
                }
                IconButton(onClick = onMinimize, modifier = Modifier.size(34.dp)) {
                    Text("—", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
                IconButton(onClick = onClose, modifier = Modifier.size(34.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Tutup FloatAI")
                }
            }

            // Mode
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ChatMode.entries.forEach { m ->
                    FilterChip(
                        selected = state.mode == m,
                        onClick = { vm.setMode(m) },
                        label = { Text(m.label, fontSize = 12.sp) }
                    )
                }
            }

            // Shortcut
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ActionButton("📷 Analisis") { vm.analyzeScreen() }
                ActionButton("🔄 Refresh") { vm.refreshScreen() }
                ActionButton("💬 Tanya") {
                    focusRequester.requestFocus()
                    keyboard?.show()
                }
                if (captureActive) ActionButton("⏹ Stop Capture") { vm.stopCapture() }
            }

            // Indikator capture
            if (captureActive) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(Color.Red))
                    Spacer(Modifier.size(6.dp))
                    val t = state.screenshotTime?.let { " • screenshot ${TimeUtil.hm(it)}" } ?: " • belum ada screenshot"
                    Text("Screen capture AKTIF$t", fontSize = 11.sp, color = Color.Red)
                }
            } else {
                Text(
                    "Screen capture tidak aktif",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Pesan
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(messages, key = { it.id }) { MessageItem(it) }
                state.pending?.let {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                            Column(Modifier.padding(10.dp)) {
                                Text("Kirim screenshot ke penyedia AI?", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(
                                    "Pastikan layar tidak menampilkan password, OTP, kartu pembayaran, atau data pribadi.",
                                    fontSize = 12.sp
                                )
                                Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                                    TextButton(onClick = { vm.cancelSend() }) { Text("Batal") }
                                    Button(onClick = { vm.confirmSend() }) { Text("Kirim") }
                                }
                            }
                        }
                    }
                }
                if (state.loading) {
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(4.dp)) {
                            CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.size(8.dp))
                            Text("FloatAI sedang bekerja…", fontSize = 12.sp)
                        }
                    }
                }
            }

            // Input
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = vm.draft,
                    onValueChange = { vm.draft = it },
                    placeholder = { Text("Ketik pertanyaan...", fontSize = 13.sp) },
                    modifier = Modifier.weight(1f).focusRequester(focusRequester),
                    maxLines = 3
                )
                IconButton(
                    enabled = !state.loading && vm.draft.isNotBlank(),
                    onClick = {
                        val text = vm.draft
                        vm.draft = ""
                        vm.send(text)
                    }
                ) { Icon(Icons.Default.Send, contentDescription = "Kirim") }
            }
        }
    }
}

@Composable
private fun ActionButton(label: String, onClick: () -> Unit) {
    FilledTonalButton(
        onClick = onClick,
        contentPadding = PaddingValues(horizontal = 12.dp),
        modifier = Modifier.height(34.dp)
    ) { Text(label, fontSize = 12.sp) }
}

@Composable
private fun MessageItem(m: ChatMessage) {
    val clipboard = LocalClipboardManager.current
    when (m.role) {
        Role.INFO -> Text(
            m.text,
            fontSize = 11.sp,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
        )
        Role.USER -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Surface(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.widthIn(max = 320.dp)
            ) {
                Column(Modifier.padding(8.dp)) {
                    if (m.hasScreenshot) Text("📷 + screenshot", fontSize = 10.sp)
                    Text(m.text, fontSize = 14.sp)
                }
            }
        }
        Role.ASSISTANT -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
            Surface(
                color = if (m.isError) MaterialTheme.colorScheme.errorContainer
                else MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.widthIn(max = 340.dp)
            ) {
                Column(Modifier.padding(8.dp)) {
                    Text(m.text, fontSize = 14.sp)
                    if (!m.isError) {
                        TextButton(
                            onClick = { clipboard.setText(AnnotatedString(m.text)) },
                            contentPadding = PaddingValues(0.dp)
                        ) { Text("📋 Salin", fontSize = 12.sp) }
                    }
                }
            }
        }
    }
}
