package com.floatai.app

import android.app.Application
import com.floatai.app.ai.AIClient
import com.floatai.app.ai.OpenAiCompatibleClient
import com.floatai.app.data.ChatRepository
import com.floatai.app.data.SettingsStore

class FloatAIApp : Application() {
    lateinit var settings: SettingsStore
        private set
    lateinit var chatRepository: ChatRepository
        private set
    lateinit var aiClient: AIClient
        private set

    override fun onCreate() {
        super.onCreate()
        settings = SettingsStore(this)
        chatRepository = ChatRepository(this, settings)
        aiClient = OpenAiCompatibleClient(settings)
    }
}
