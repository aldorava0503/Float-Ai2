package com.floatai.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.floatai.app.MainActivity
import com.floatai.app.R

object Notifications {
    private const val CHANNEL_ID = "floatai_status"

    private fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Status FloatAI", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    fun floating(ctx: Context): Notification {
        ensureChannel(ctx)
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            ctx, 1,
            Intent(ctx, FloatingService::class.java).setAction(FloatingService.ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("FloatAI aktif")
            .setContentText("Bubble melayang sedang ditampilkan.")
            .setContentIntent(open)
            .addAction(0, "Matikan", stop)
            .setOngoing(true)
            .build()
    }

    fun capture(ctx: Context): Notification {
        ensureChannel(ctx)
        val stop = PendingIntent.getService(
            ctx, 2,
            Intent(ctx, CaptureService::class.java).setAction(CaptureService.ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(ctx, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("● Screen capture AKTIF")
            .setContentText("Screenshot hanya diambil saat Anda menekan Analisis/Refresh.")
            .addAction(0, "Berhenti", stop)
            .setOngoing(true)
            .build()
    }
}
