package com.floatai.app.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.content.ContextCompat
import com.floatai.app.FloatAIApp
import com.floatai.app.capture.ScreenCaptureManager
import com.floatai.app.overlay.OverlayManager
import com.floatai.app.permission.PermissionHandler
import com.floatai.app.ui.ChatViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class FloatingService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var overlay: OverlayManager? = null
    private var viewModel: ChatViewModel? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val n = Notifications.floating(this)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }

        if (!PermissionHandler.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        val app = application as FloatAIApp
        val vm = ChatViewModel(app.chatRepository, app.settings, app.aiClient)
        vm.permissionRequester = { PermissionHandler.requestCapturePermission(this) }
        val om = OverlayManager(this, vm, app.settings, scope) { stopSelf() }
        vm.overlayController = om
        om.show()

        viewModel = vm
        overlay = om
        _running.value = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) stopSelf()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        overlay?.destroy()
        viewModel?.dispose()
        ScreenCaptureManager.stop() // menutup bubble = menghentikan capture
        scope.cancel()
        _running.value = false
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.floatai.app.FLOATING_STOP"
        private const val NOTIF_ID = 2001
        private val _running = MutableStateFlow(false)
        val running: StateFlow<Boolean> = _running.asStateFlow()

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, FloatingService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, FloatingService::class.java))
        }
    }
}
