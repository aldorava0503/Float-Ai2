package com.floatai.app.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.floatai.app.capture.ScreenCaptureManager
import com.floatai.app.data.AppSettings
import kotlinx.coroutines.flow.StateFlow

@Composable
fun BubbleContent(settings: StateFlow<AppSettings>) {
    val s by settings.collectAsState()
    val captureActive by ScreenCaptureManager.active.collectAsState()
    val pulse = rememberInfiniteTransition(label = "pulse")
    val scale by pulse.animateFloat(
        initialValue = 1f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "scale"
    )
    Box(Modifier.padding(4.dp)) {
        Box(
            modifier = Modifier
                .size(s.bubbleSizeDp.dp)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    alpha = s.bubbleAlpha
                }
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Color(0xFF6C5CE7), Color(0xFF00B8D9)))),
            contentAlignment = Alignment.Center
        ) {
            Text(
                "AI",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = (s.bubbleSizeDp * 0.32f).sp
            )
        }
        if (captureActive) {
            // Indikator merah: screen capture sedang aktif
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .size(12.dp)
                    .clip(CircleShape)
                    .background(Color.Red)
            )
        }
    }
}
