package com.floatai.app.overlay

import android.app.Service
import android.content.Context
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.compose.ui.platform.ComposeView
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.floatai.app.data.SettingsStore
import com.floatai.app.ui.BubbleContent
import com.floatai.app.ui.ChatViewModel
import com.floatai.app.ui.FloatAITheme
import com.floatai.app.ui.FloatingPanel
import com.floatai.app.util.DisplayUtil
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlin.math.min

/**
 * Mengelola dua window overlay resmi (TYPE_APPLICATION_OVERLAY):
 *  - bubble kecil (tidak fokus, hanya menyentuh area bubble; sisa layar tetap bisa dipakai)
 *  - panel chat (non-modal: sentuhan di luar panel diteruskan ke aplikasi di bawahnya)
 */
class OverlayManager(
    private val service: Service,
    private val viewModel: ChatViewModel,
    private val settings: SettingsStore,
    private val scope: CoroutineScope,
    private val onClose: () -> Unit
) : OverlayController {

    private val wm = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val owner = OverlayLifecycleOwner()
    private val density = service.resources.displayMetrics.density
    private var bubble: DraggableBubbleLayout? = null
    private var panel: ComposeView? = null
    private var panelOpen = false

    private val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    fun show() {
        owner.resume()
        addBubble()
        scope.launch {
            settings.flow.map { it.bubbleSide }.distinctUntilChanged().drop(1).collect {
                bubble?.snapToSide()
            }
        }
    }

    private fun attachOwner(v: View) {
        v.setViewTreeLifecycleOwner(owner)
        v.setViewTreeViewModelStoreOwner(owner)
        v.setViewTreeSavedStateRegistryOwner(owner)
    }

    private fun addBubble() {
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = settings.current.bubbleY
        }
        val layout = DraggableBubbleLayout(
            service, params, wm,
            screen = { DisplayUtil.realSize(service) },
            sidePref = { settings.current.bubbleSide },
            onTap = { openPanel() },
            onDropped = { y -> settings.update { it.copy(bubbleY = y) } }
        )
        val compose = ComposeView(service).apply {
            setContent { FloatAITheme { BubbleContent(settings.flow) } }
        }
        layout.addView(compose)
        attachOwner(layout)
        attachOwner(compose)
        wm.addView(layout, params)
        bubble = layout
        layout.post { layout.snapToSide() }
    }

    private fun openPanel() {
        if (panelOpen) return
        val size = DisplayUtil.realSize(service)
        val w = min((size.x * 0.94f).toInt(), (420 * density).toInt())
        val h = (size.y * 0.58f).toInt()
        val params = WindowManager.LayoutParams(
            w, h, type,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, // fokus aktif agar keyboard bisa muncul
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = (24 * density).toInt()
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        val view = ComposeView(service).apply {
            setContent {
                FloatAITheme {
                    FloatingPanel(viewModel, onMinimize = { minimize() }, onClose = onClose)
                }
            }
        }
        attachOwner(view)
        wm.addView(view, params)
        panel = view
        panelOpen = true
        bubble?.visibility = View.GONE
    }

    private fun minimize() {
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
        panelOpen = false
        bubble?.visibility = View.VISIBLE
    }

    override suspend fun hideForCapture() {
        panel?.visibility = View.INVISIBLE
        bubble?.visibility = View.INVISIBLE
        delay(350) // beri waktu sistem menggambar ulang tanpa overlay
    }

    override fun restoreAfterCapture() {
        panel?.visibility = View.VISIBLE
        if (!panelOpen) bubble?.visibility = View.VISIBLE
    }

    fun destroy() {
        panel?.let { runCatching { wm.removeView(it) } }
        bubble?.let { runCatching { wm.removeView(it) } }
        panel = null
        bubble = null
        owner.destroy()
    }
}
