package com.floatai.app.overlay

import android.content.Context
import android.graphics.Point
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import com.floatai.app.data.BubbleSide
import kotlin.math.abs

/** Container bubble: menangani drag (pakai koordinat raw agar mulus) + tap + snap ke sisi layar. */
class DraggableBubbleLayout(
    context: Context,
    private val params: WindowManager.LayoutParams,
    private val wm: WindowManager,
    private val screen: () -> Point,
    private val sidePref: () -> BubbleSide,
    private val onTap: () -> Unit,
    private val onDropped: (y: Int) -> Unit
) : FrameLayout(context) {

    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0
    private var dragging = false

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean = true

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX; downY = e.rawY
                startX = params.x; startY = params.y
                dragging = false
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downX
                val dy = e.rawY - downY
                if (!dragging && (abs(dx) > slop || abs(dy) > slop)) dragging = true
                if (dragging) {
                    params.x = startX + dx.toInt()
                    params.y = startY + dy.toInt()
                    wm.updateViewLayout(this, params)
                }
            }
            MotionEvent.ACTION_UP -> {
                if (!dragging) {
                    performClick()
                    onTap()
                } else {
                    snapToSide()
                    onDropped(params.y)
                }
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    fun snapToSide() {
        val sz = screen()
        val w = width.coerceAtLeast(1)
        val left = when (sidePref()) {
            BubbleSide.LEFT -> true
            BubbleSide.RIGHT -> false
            BubbleSide.NEAREST -> params.x + w / 2 < sz.x / 2
        }
        params.x = if (left) 0 else sz.x - w
        params.y = params.y.coerceIn(0, (sz.y - height).coerceAtLeast(0))
        if (isAttachedToWindow) wm.updateViewLayout(this, params)
    }
}
